from pymongo.asynchronous.mongo_client import AsyncMongoClient
from pymongo.asynchronous.database import AsyncDatabase
from config.settings import get_settings

settings = get_settings()

class Database:
    client: AsyncMongoClient | None = None
    db: AsyncDatabase | None = None

db_manager = Database()

async def connect_to_mongo():
    """Kết nối đến MongoDB khi server khởi động."""
    print("Đang kết nối đến MongoDB...")
    try:
        db_manager.client = AsyncMongoClient(settings.mongo_connection_string)
        db_manager.db = db_manager.client[settings.mongo_db_name]
        await db_manager.client.admin.command('ping')
        print(f"Đã kết nối thành công đến MongoDB, database: '{settings.mongo_db_name}'")
    except Exception as e:
        print(f"Lỗi kết nối MongoDB: {e}")
        db_manager.client = None
        db_manager.db = None

async def close_mongo_connection():
    """Đóng kết nối MongoDB khi server tắt."""
    print("Đang đóng kết nối MongoDB...")
    if db_manager.client:
        db_manager.client.close()
        print("Đã đóng kết nối MongoDB!")

def get_database() -> AsyncDatabase:
    """Lấy đối tượng database để thực hiện truy vấn."""
    if db_manager.db is None:
        # Bạn có thể thêm xử lý lỗi ở đây nếu cần
        raise Exception("Database chưa được kết nối!")
    return db_manager.db