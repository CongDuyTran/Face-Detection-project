from insightface.app import FaceAnalysis

def load_face_embedder():
    face_embedder = FaceAnalysis(providers=['CPUExecutionProvider'])
    face_embedder.prepare(ctx_id=0, det_size=(640, 640))
    return face_embedder