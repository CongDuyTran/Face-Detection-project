from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache # Để cache settings
from fastapi.security import OAuth2PasswordBearer

class Settings(BaseSettings):
    # Biến môi trường sẽ tự động được load vào đây
    # oauth2_scheme: OAuth2PasswordBearer = OAuth2PasswordBearer(tokenUrl='/auth/login')
    # user_agent: str
    secret_key: str
    hash_algo: str
    access_token_expire_minutes: int
    mongo_connection_string: str
    mongo_db_name: str
    users_collection: str
    events_collection: str
    checkins_collection: str

    # Chỉ định đọc từ file .env
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

# Sử dụng lru_cache để đảm bảo settings chỉ được load một lần
@lru_cache
def get_settings() -> Settings:
    return Settings()