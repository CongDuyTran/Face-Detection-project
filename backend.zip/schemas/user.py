from pydantic import BaseModel

class UserCreate(BaseModel):
    name: str
    # unit: str
    # position: str
    email: str
    phone_number: str

class UserUpdate(BaseModel):
    email: str | None = None