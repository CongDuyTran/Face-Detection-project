from datetime import datetime
from pydantic import BaseModel

class Event(BaseModel):
    name: str
    place_details: dict
    start_time: datetime
    end_time: datetime