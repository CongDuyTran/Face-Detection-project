import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager

from middlewares.cors import set_cors
from models.base import load_face_embedder
from routes.base import routers
from services.db import connect_to_mongo, close_mongo_connection

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Code to run during application startup
    # Connect to MongoDB
    await connect_to_mongo()

    # Load models
    app.state.face_embedder = load_face_embedder()

    yield # The application is now ready to serve requests

    # Code to run during application shutdown
    # Disconnect from MongoDB
    await close_mongo_connection()

app = FastAPI(lifespan=lifespan)
set_cors(app)
app.include_router(routers)

if __name__ == "__main__":
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)