from fastapi import APIRouter

from routes.events_route import router as events_router
from routes.checkins_route import router as checkins_router
from routes.users_route import router as users_router

routers = APIRouter(prefix="/api/v1")
routers.include_router(events_router)
routers.include_router(checkins_router)
routers.include_router(users_router)