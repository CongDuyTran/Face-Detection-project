import asyncio, json, numpy as np, base64
from bson.objectid import ObjectId
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, Request, HTTPException
from sse_starlette.sse import EventSourceResponse

from services.db import get_database # Giả sử bạn có hàm này
from config.settings import get_settings
from services.db import get_database

# --- CẤU HÌNH ---
COSINE_THRESHOLD = 0.4 # Ngưỡng tương đồng, bạn cần tinh chỉnh

router = APIRouter(prefix="/checkins", tags=["Check-Ins"])
checkin_queue = asyncio.Queue()
last_data = None
settings = get_settings()

# --- TẢI "THƯ VIỆN" EMBEDDING KHI SERVER KHỞI ĐỘNG ---
# --- TẠO "THƯ VIỆN" TRONG BỘ NHỚ ---
# Biến toàn cục để lưu trữ dữ liệu người dùng đã được tải
USER_LIBRARY = {
    "ids": [],
    "names": [],
    'units': [],
    'positions': [],
    'phone_numbers': [],
    'emails': [],
    'images_b64': [],
    "embeddings": None # Sẽ là một ma trận NumPy
}

# --- HÀM TẢI DỮ LIỆU TỪ DB ---
async def load_users_from_db(db):
    print("Server: Bắt đầu tải dữ liệu người dùng vào bộ nhớ...")
    events_collection = db[settings.events_collection]
    users_collection = db[settings.users_collection]
    
    # Lấy tất cả người dùng từ DB
    users_cursor = users_collection.find()
    all_users = []
    async for doc in users_cursor:
        all_users.append(doc)
    
     # Kiểm tra nếu không có người dùng nào
    if not all_users:
        print("Cảnh báo: Không tìm thấy người dùng nào trong database.")
        return

    # Tách dữ liệu ra các list riêng
    USER_LIBRARY["ids"] = [str(user["_id"]) for user in all_users]
    USER_LIBRARY["names"] = [user["name"] for user in all_users]
    USER_LIBRARY['units'] = [user['unit'] for user in all_users]
    USER_LIBRARY['positions'] = [user['position'] for user in all_users]
    USER_LIBRARY['phone_numbers'] = [user['phone_number'] for user in all_users]
    USER_LIBRARY['emails'] = [user['email'] for user in all_users]
    USER_LIBRARY['images_b64'] = [base64.b64encode(user['image_binary']).decode('utf-8') for user in all_users]
    
    # Tạo một ma trận NumPy từ tất cả các embedding
    embeddings_list = [user["image_embedding"] for user in all_users]
    USER_LIBRARY["embeddings"] = np.array(embeddings_list, dtype=np.float32)
    
    print(f"✅ Đã tải thành công {len(USER_LIBRARY['ids'])} người dùng vào bộ nhớ.")

@router.websocket('/ws')
async def websocket_camera(ws: WebSocket, db=Depends(get_database)):
    global last_data
    await ws.accept()
    print("Server: Client đã kết nối.")
    await load_users_from_db(db)

    try:
        while True:
            data_str = await ws.receive_text()
            data = json.loads(data_str)
            received_embedding = np.array(data["embedding"], dtype=np.float32)

            if received_embedding.size == 0:
                continue

            # --- SO SÁNH SIÊU NHANH BẰNG PHÉP TOÁN VECTOR ---
            # Thay vì vòng lặp for, chúng ta dùng phép nhân ma trận (dot product)
            # để tính toán độ tương đồng với TẤT CẢ người dùng cùng một lúc.
            similarities = np.dot(USER_LIBRARY["embeddings"], received_embedding)
            
            # Tìm vị trí (index) của người có độ tương đồng cao nhất
            best_match_index = np.argmax(similarities)
            best_match_score = similarities[best_match_index]

            response = {"status": "not_found"}

            if best_match_score > COSINE_THRESHOLD:
                user_id = USER_LIBRARY["ids"][best_match_index]
                user_name = USER_LIBRARY["names"][best_match_index]
                unit = USER_LIBRARY['units'][best_match_index]
                position = USER_LIBRARY['positions'][best_match_index]
                phone_number = USER_LIBRARY['phone_numbers'][best_match_index]
                email = USER_LIBRARY['emails'][best_match_index]
                image_b64 = USER_LIBRARY['images_b64'][best_match_index]
                response = {
                    "id": user_id,
                    "name": user_name,
                    'unit': unit,
                    'position': position,
                    'phone_number': phone_number,
                    'email': email,
                    'image_b64': image_b64,
                    "status": 'Đã check-in',
                    'checkin_time': None
                }

                if response != last_data:
                    await checkin_queue.put(response)
                    last_data = response
            
            await ws.send_json(response)

    except WebSocketDisconnect:
        print("Server: Client đã ngắt kết nối.")
    except Exception as e:
        print(f"Server: Đã có lỗi xảy ra - {e}")

@router.get('/stream/dashboard')
async def stream_checkins(req: Request, db=Depends(get_database)):
    async def event_generator():
        while True:
            if await req.is_disconnected():
                break
            try:
                data = await checkin_queue.get()

                checkins_collection = db[settings.checkins_collection]
                await checkins_collection.insert_one({
                    'event_id': ObjectId('68aab849d67da426f957c1d3'),
                    'user_id': ObjectId(data['id']),
                    'status': True,
                    'checkin_time': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                })

            
                yield {
                    "event": "checkin",
                    "data": json.dumps(data)
                }
            except asyncio.CancelledError:
                break
    try:
        return EventSourceResponse(event_generator())
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=str(e))