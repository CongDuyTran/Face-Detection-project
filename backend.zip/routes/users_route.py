import cv2, numpy as np
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Request
from bson import Binary

from config.settings import get_settings
from services.db import get_database
from schemas.user import UserCreate, UserUpdate

router = APIRouter(prefix="/users", tags=["Users"])
settings = get_settings()

@router.get("")
async def get_users(db=Depends(get_database)):
    pass

@router.post("", status_code=201)
async def add_user(
    user: UserCreate=Form(),
    db=Depends(get_database)
):
    users_collection = db[settings.users_collection]
    
    # Kiểm tra nếu email đã tồn tại
    existing_user = await users_collection.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email đã được sử dụng.")
    
    # Chèn người dùng mới vào DB
    user_doc = {
        **user.dict(),
        'unit': None,
        'position': None
    }
    result = await users_collection.insert_one(user_doc)
    
    return {"id": str(result.inserted_id), "message": "Người dùng đã được thêm thành công."}
    
@router.post("/upload", status_code=201)
async def upload_image(
    req: Request,
    email: str=Form(...),
    file: UploadFile=File(...),
    db=Depends(get_database)
):
    # Đọc nội dung file
    image_bytes = await file.read()
    np_array = np.frombuffer(image_bytes, np.uint8)
    mat_image = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)
    if mat_image is None:
        raise HTTPException(status_code=500, detail='Something happened with the image!')
    
    faces = req.app.state.face_embedder.get(mat_image)
    if not faces:
        raise HTTPException(status_code=500, detail='No faces detected!')
    
    main_face = faces[0]
    norm_embedding = main_face.normed_embedding

    # Lưu vào MongoDB
    try:
        users_collection = db[settings.users_collection]
        await users_collection.update_one(
            {"email": email},
            {
                "$set": {
                    'image_embedding': norm_embedding.tolist(),
                    "image_binary": Binary(image_bytes)
                }
            }
        )
        return {"message": "Upload thành công"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))