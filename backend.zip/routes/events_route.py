from fastapi import APIRouter, HTTPException, Depends

from config.settings import get_settings
from services.db import get_database

router = APIRouter(prefix="/events", tags=["Events"])
settings = get_settings()

@router.get("")
async def get_events(db=Depends(get_database)):
    try:
        events_collection = db[settings.events_collection]
        events_cursor = events_collection.find().sort("start_time", 1)
        # Tạo một list rỗng để chứa kết quả
        result_list = []

        # SỬ DỤNG VÒNG LẶP ASYNC FOR
        async for event in events_cursor:
            result_list.append({
                'id': str(event['_id']),
                'name': event['name'],
                'place_details': event['place_details'],
                'start_time': event['start_time'],
                'end_time': event['end_time']
            })
        
        return result_list
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))